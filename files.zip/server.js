const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());

const NBA_HEADERS = {
  'Host': 'stats.nba.com',
  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'en-US,en;q=0.9',
  'Accept-Encoding': 'gzip, deflate, br',
  'x-nba-stats-origin': 'stats',
  'x-nba-stats-token': 'true',
  'Connection': 'keep-alive',
  'Referer': 'https://www.nba.com/',
  'Origin': 'https://www.nba.com',
};

// League leaders (points, rebounds, assists, steals, blocks)
app.get('/api/leaders', async (req, res) => {
  try {
    const { stat = 'PTS', season = '2025-26' } = req.query;
    const url = `https://stats.nba.com/stats/leagueleaders?LeagueID=00&PerMode=PerGame&Scope=S&Season=${season}&SeasonType=Regular+Season&StatCategory=${stat}`;
    const response = await axios.get(url, { headers: NBA_HEADERS, timeout: 10000 });
    res.json(response.data);
  } catch (err) {
    console.error('Leaders error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Standings
app.get('/api/standings', async (req, res) => {
  try {
    const url = `https://stats.nba.com/stats/leaguestandingsv3?LeagueID=00&Season=2025-26&SeasonType=Regular+Season&SeasonYear=2025-26`;
    const response = await axios.get(url, { headers: NBA_HEADERS, timeout: 10000 });
    res.json(response.data);
  } catch (err) {
    console.error('Standings error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Today's scoreboard
app.get('/api/scoreboard', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const url = `https://cdn.nba.com/static/json/liveData/scoreboard/todaysScoreboard_00.json`;
    const response = await axios.get(url, {
      headers: { ...NBA_HEADERS, Host: 'cdn.nba.com' },
      timeout: 10000
    });
    res.json(response.data);
  } catch (err) {
    console.error('Scoreboard error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// News (ESPN RSS via proxy)
app.get('/api/news', async (req, res) => {
  try {
    const url = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news?limit=8';
    const response = await axios.get(url, { timeout: 10000 });
    res.json(response.data);
  } catch (err) {
    console.error('News error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`\n🏀 NBA Proxy Server running on http://localhost:${PORT}`);
  console.log(`   Endpoints:`);
  console.log(`   GET /api/leaders?stat=PTS`);
  console.log(`   GET /api/leaders?stat=REB`);
  console.log(`   GET /api/leaders?stat=AST`);
  console.log(`   GET /api/leaders?stat=STL`);
  console.log(`   GET /api/leaders?stat=BLK`);
  console.log(`   GET /api/standings`);
  console.log(`   GET /api/scoreboard`);
  console.log(`   GET /api/news\n`);
});
